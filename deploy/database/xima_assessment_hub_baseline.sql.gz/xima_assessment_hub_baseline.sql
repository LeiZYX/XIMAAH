-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: xima_assessment_hub
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `xima_assessment_hub`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `xima_assessment_hub` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `xima_assessment_hub`;

--
-- Table structure for table `AccessToScriptRequest`
--

DROP TABLE IF EXISTS `AccessToScriptRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AccessToScriptRequest` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationItemId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examSessionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paperId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('DRAFT','SUBMITTED','SENT_TO_BOARD','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `requestedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `feeStatementId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `AccessToScriptRequest_reviewWindowId_idx` (`reviewWindowId`),
  KEY `AccessToScriptRequest_candidateId_idx` (`candidateId`),
  KEY `AccessToScriptRequest_examBoardId_idx` (`examBoardId`),
  KEY `AccessToScriptRequest_status_idx` (`status`),
  KEY `AccessToScriptRequest_examSeriesId_fkey` (`examSeriesId`),
  KEY `AccessToScriptRequest_registrationItemId_fkey` (`registrationItemId`),
  KEY `AccessToScriptRequest_examSessionId_fkey` (`examSessionId`),
  KEY `AccessToScriptRequest_subjectId_fkey` (`subjectId`),
  KEY `AccessToScriptRequest_paperId_fkey` (`paperId`),
  KEY `AccessToScriptRequest_requestedByUserId_fkey` (`requestedByUserId`),
  KEY `AccessToScriptRequest_feeStatementId_fkey` (`feeStatementId`),
  CONSTRAINT `AccessToScriptRequest_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AccessToScriptRequest_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AccessToScriptRequest_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AccessToScriptRequest_examSessionId_fkey` FOREIGN KEY (`examSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AccessToScriptRequest_feeStatementId_fkey` FOREIGN KEY (`feeStatementId`) REFERENCES `FeeStatement` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AccessToScriptRequest_paperId_fkey` FOREIGN KEY (`paperId`) REFERENCES `Paper` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AccessToScriptRequest_registrationItemId_fkey` FOREIGN KEY (`registrationItemId`) REFERENCES `StudentExamRegistration` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AccessToScriptRequest_requestedByUserId_fkey` FOREIGN KEY (`requestedByUserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AccessToScriptRequest_reviewWindowId_fkey` FOREIGN KEY (`reviewWindowId`) REFERENCES `ReviewWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AccessToScriptRequest_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AccessToScriptRequest`
--

LOCK TABLES `AccessToScriptRequest` WRITE;
/*!40000 ALTER TABLE `AccessToScriptRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `AccessToScriptRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CalendarSubjectSelection`
--

DROP TABLE IF EXISTS `CalendarSubjectSelection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CalendarSubjectSelection` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `CalendarSubjectSelection_examBoardId_subjectId_key` (`examBoardId`,`subjectId`),
  KEY `CalendarSubjectSelection_examBoardId_idx` (`examBoardId`),
  KEY `CalendarSubjectSelection_subjectId_idx` (`subjectId`),
  CONSTRAINT `CalendarSubjectSelection_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CalendarSubjectSelection_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CalendarSubjectSelection`
--

LOCK TABLES `CalendarSubjectSelection` WRITE;
/*!40000 ALTER TABLE `CalendarSubjectSelection` DISABLE KEYS */;
/*!40000 ALTER TABLE `CalendarSubjectSelection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Candidate`
--

DROP TABLE IF EXISTS `Candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Candidate` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assessmentHubCandidateNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateType` enum('INTERNAL','EXTERNAL') COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `studentNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `englishName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chineseName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateOfBirth` datetime(3) DEFAULT NULL,
  `idNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passportNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schoolName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grade` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `className` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','GRADUATED','LEFT','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `loginEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `sourceSystem` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `externalId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `surnamePinyin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `givenNamePinyin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preferredEnglishName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `legalEnglishName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idDocumentType` enum('CHINESE_ID_CARD','PASSPORT','HONG_KONG_ID','MACAU_ID','TAIWAN_ID','OTHER') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idDocumentNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photoUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyContactName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyContactPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graduationYear` int DEFAULT NULL,
  `gender` enum('MALE','FEMALE','OTHER','PREFER_NOT_TO_SAY') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Candidate_userId_key` (`userId`),
  KEY `Candidate_candidateType_idx` (`candidateType`),
  KEY `Candidate_status_idx` (`status`),
  KEY `Candidate_assessmentHubCandidateNumber_idx` (`assessmentHubCandidateNumber`),
  KEY `Candidate_studentNumber_idx` (`studentNumber`),
  KEY `Candidate_englishName_idx` (`englishName`),
  KEY `Candidate_grade_idx` (`grade`),
  KEY `Candidate_className_idx` (`className`),
  KEY `Candidate_externalId_idx` (`externalId`),
  CONSTRAINT `Candidate_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Candidate`
--

LOCK TABLES `Candidate` WRITE;
/*!40000 ALTER TABLE `Candidate` DISABLE KEYS */;
INSERT INTO `Candidate` VALUES ('cmr0vixb1001flz8b51qgi1ba','AH-2026-1JIFPY','INTERNAL','cmr0viwss0006lz8b9nzdsicd','S2026001','Sample Student',NULL,'student@xima.local','+8613800000002',NULL,NULL,NULL,NULL,'Year 12','12A','ACTIVE',1,'STUDENT_PROFILE',NULL,'2026-06-30 16:41:24.254','2026-06-30 16:41:24.254',NULL,NULL,NULL,'Sample Student',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cmr0vixba001hlz8bwcmfmfpb','AH-2026-PJYEQ8','INTERNAL','cmr0vix7i0009lz8be7nmdm2v','S2026002','Test Student Two',NULL,'student2@xima.local','+8613800000003',NULL,NULL,NULL,NULL,'Year 11','11B','ACTIVE',1,'STUDENT_PROFILE',NULL,'2026-06-30 16:41:24.262','2026-06-30 16:41:24.262',NULL,NULL,NULL,'Test Student Two',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CandidateAuditLog`
--

DROP TABLE IF EXISTS `CandidateAuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CandidateAuditLog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` enum('CANDIDATE_IDENTITY_UPDATED','CANDIDATE_PHOTO_UPLOADED','CANDIDATE_PHOTO_REMOVED','CANDIDATE_NAME_CHANGED','DOCUMENT_NUMBER_CHANGED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `performedById` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `CandidateAuditLog_candidateId_idx` (`candidateId`),
  KEY `CandidateAuditLog_action_idx` (`action`),
  KEY `CandidateAuditLog_performedById_idx` (`performedById`),
  KEY `CandidateAuditLog_createdAt_idx` (`createdAt`),
  CONSTRAINT `CandidateAuditLog_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CandidateAuditLog_performedById_fkey` FOREIGN KEY (`performedById`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CandidateAuditLog`
--

LOCK TABLES `CandidateAuditLog` WRITE;
/*!40000 ALTER TABLE `CandidateAuditLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `CandidateAuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CandidateBoardRegistration`
--

DROP TABLE IF EXISTS `CandidateBoardRegistration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CandidateBoardRegistration` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registered` tinyint(1) NOT NULL DEFAULT '0',
  `registrationFeePaid` tinyint(1) NOT NULL DEFAULT '0',
  `registrationFeePaidAt` datetime(3) DEFAULT NULL,
  `feeStatementId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CandidateBoardRegistration_candidateId_examBoardId_key` (`candidateId`,`examBoardId`),
  KEY `CandidateBoardRegistration_examBoardId_idx` (`examBoardId`),
  KEY `CandidateBoardRegistration_registrationFeePaid_idx` (`registrationFeePaid`),
  KEY `CandidateBoardRegistration_feeStatementId_fkey` (`feeStatementId`),
  CONSTRAINT `CandidateBoardRegistration_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CandidateBoardRegistration_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CandidateBoardRegistration_feeStatementId_fkey` FOREIGN KEY (`feeStatementId`) REFERENCES `FeeStatement` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CandidateBoardRegistration`
--

LOCK TABLES `CandidateBoardRegistration` WRITE;
/*!40000 ALTER TABLE `CandidateBoardRegistration` DISABLE KEYS */;
/*!40000 ALTER TABLE `CandidateBoardRegistration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CandidateExamIdentity`
--

DROP TABLE IF EXISTS `CandidateExamIdentity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CandidateExamIdentity` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `centreNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boardCandidateNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uci` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CandidateExamIdentity_candidateId_examBoardId_key` (`candidateId`,`examBoardId`),
  KEY `CandidateExamIdentity_candidateId_idx` (`candidateId`),
  KEY `CandidateExamIdentity_examBoardId_idx` (`examBoardId`),
  KEY `CandidateExamIdentity_boardCandidateNumber_idx` (`boardCandidateNumber`),
  CONSTRAINT `CandidateExamIdentity_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CandidateExamIdentity_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CandidateExamIdentity`
--

LOCK TABLES `CandidateExamIdentity` WRITE;
/*!40000 ALTER TABLE `CandidateExamIdentity` DISABLE KEYS */;
/*!40000 ALTER TABLE `CandidateExamIdentity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CashInRequest`
--

DROP TABLE IF EXISTS `CashInRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CashInRequest` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualificationId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('DRAFT','SUBMITTED','SENT_TO_BOARD','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `requestedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `feeStatementId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CashInRequest_reviewWindowId_idx` (`reviewWindowId`),
  KEY `CashInRequest_candidateId_idx` (`candidateId`),
  KEY `CashInRequest_examBoardId_idx` (`examBoardId`),
  KEY `CashInRequest_status_idx` (`status`),
  KEY `CashInRequest_examSeriesId_fkey` (`examSeriesId`),
  KEY `CashInRequest_qualificationId_fkey` (`qualificationId`),
  KEY `CashInRequest_subjectId_fkey` (`subjectId`),
  KEY `CashInRequest_requestedByUserId_fkey` (`requestedByUserId`),
  KEY `CashInRequest_feeStatementId_fkey` (`feeStatementId`),
  CONSTRAINT `CashInRequest_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CashInRequest_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CashInRequest_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CashInRequest_feeStatementId_fkey` FOREIGN KEY (`feeStatementId`) REFERENCES `FeeStatement` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CashInRequest_qualificationId_fkey` FOREIGN KEY (`qualificationId`) REFERENCES `Qualification` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CashInRequest_requestedByUserId_fkey` FOREIGN KEY (`requestedByUserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CashInRequest_reviewWindowId_fkey` FOREIGN KEY (`reviewWindowId`) REFERENCES `ReviewWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CashInRequest_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CashInRequest`
--

LOCK TABLES `CashInRequest` WRITE;
/*!40000 ALTER TABLE `CashInRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `CashInRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CertificateRequest`
--

DROP TABLE IF EXISTS `CertificateRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CertificateRequest` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewWindowId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('DRAFT','SUBMITTED','SENT_TO_BOARD','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `requestedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `feeStatementId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CertificateRequest_reviewWindowId_idx` (`reviewWindowId`),
  KEY `CertificateRequest_candidateId_idx` (`candidateId`),
  KEY `CertificateRequest_examBoardId_idx` (`examBoardId`),
  KEY `CertificateRequest_status_idx` (`status`),
  KEY `CertificateRequest_examSeriesId_fkey` (`examSeriesId`),
  KEY `CertificateRequest_requestedByUserId_fkey` (`requestedByUserId`),
  KEY `CertificateRequest_feeStatementId_fkey` (`feeStatementId`),
  CONSTRAINT `CertificateRequest_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CertificateRequest_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CertificateRequest_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CertificateRequest_feeStatementId_fkey` FOREIGN KEY (`feeStatementId`) REFERENCES `FeeStatement` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CertificateRequest_requestedByUserId_fkey` FOREIGN KEY (`requestedByUserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CertificateRequest_reviewWindowId_fkey` FOREIGN KEY (`reviewWindowId`) REFERENCES `ReviewWindow` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CertificateRequest`
--

LOCK TABLES `CertificateRequest` WRITE;
/*!40000 ALTER TABLE `CertificateRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `CertificateRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExamBoard`
--

DROP TABLE IF EXISTS `ExamBoard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExamBoard` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `region` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calendarSubjectFilterEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `centreName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `centreNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `centreAddress` text COLLATE utf8mb4_unicode_ci,
  `centreEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `centrePhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `centreCountry` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `centreTimeZone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defaultExamOfficerName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defaultExamOfficerEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ExamBoard_code_key` (`code`),
  KEY `ExamBoard_country_idx` (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExamBoard`
--

LOCK TABLES `ExamBoard` WRITE;
/*!40000 ALTER TABLE `ExamBoard` DISABLE KEYS */;
INSERT INTO `ExamBoard` VALUES ('cmr0vive00001lz8bhenpgld7','Pearson Edexcel','EDEXCEL','Pearson Edexcel qualifications','GB','United Kingdom','https://qualifications.pearson.com','Europe/London',0,'2026-06-30 16:41:21.768','2026-06-30 16:41:21.768',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cmr0vive00002lz8bmcjz67k5','Cambridge International','CIE','Cambridge Assessment International Education (IGCSE, AS & A Level)','GB','International','https://www.cambridgeinternational.org','Europe/London',0,'2026-06-30 16:41:21.768','2026-06-30 16:41:21.768',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cmr0vive00003lz8bb9qnnjn7','AQA','AQA','Leading exam board for GCSEs and A-Levels in England','GB','United Kingdom','https://www.aqa.org.uk','Europe/London',0,'2026-06-30 16:41:21.768','2026-06-30 16:41:21.768',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ExamBoard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExamDocumentAuditLog`
--

DROP TABLE IF EXISTS `ExamDocumentAuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExamDocumentAuditLog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` enum('EXAM_DOCUMENT_PREVIEWED','EXAM_DOCUMENT_PRINTED','EXAM_DOCUMENT_DOWNLOADED','STATEMENT_OF_ENTRY_PRINTED','ATTENDANCE_REGISTER_PRINTED','SEATING_PLAN_PRINTED','CANDIDATE_LIST_EXPORTED','RESTRICTED_REGISTRATION_CREATED','RESTRICTED_REGISTRATION_UPDATED','RESTRICTED_REGISTRATION_CANCELLED','RESTRICTED_INVOICE_PRINTED','RESTRICTED_INVOICE_DOWNLOADED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentType` enum('STATEMENT_OF_ENTRY','CANDIDATE_TIMETABLE','ATTENDANCE_REGISTER','SEATING_PLAN','DESK_LABELS','CANDIDATE_LABELS','CANDIDATE_LIST','SUBJECT_CANDIDATE_LIST','ROOM_CANDIDATE_LIST','MISSING_CANDIDATE_REPORT','NORMAL_FEE_STATEMENT','RESTRICTED_INVOICE','RESULT_SLIP','CERTIFICATE_COLLECTION_LIST') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examSessionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `candidateCount` int DEFAULT NULL,
  `performedById` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` json DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `ExamDocumentAuditLog_action_idx` (`action`),
  KEY `ExamDocumentAuditLog_documentType_idx` (`documentType`),
  KEY `ExamDocumentAuditLog_registrationWindowId_idx` (`registrationWindowId`),
  KEY `ExamDocumentAuditLog_examSessionId_idx` (`examSessionId`),
  KEY `ExamDocumentAuditLog_candidateId_idx` (`candidateId`),
  KEY `ExamDocumentAuditLog_performedById_idx` (`performedById`),
  KEY `ExamDocumentAuditLog_createdAt_idx` (`createdAt`),
  CONSTRAINT `ExamDocumentAuditLog_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ExamDocumentAuditLog_examSessionId_fkey` FOREIGN KEY (`examSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ExamDocumentAuditLog_performedById_fkey` FOREIGN KEY (`performedById`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ExamDocumentAuditLog_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExamDocumentAuditLog`
--

LOCK TABLES `ExamDocumentAuditLog` WRITE;
/*!40000 ALTER TABLE `ExamDocumentAuditLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ExamDocumentAuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExamSeries`
--

DROP TABLE IF EXISTS `ExamSeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExamSeries` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` int NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` datetime(3) DEFAULT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `sourceDocumentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ExamSeries_examBoardId_idx` (`examBoardId`),
  KEY `ExamSeries_year_idx` (`year`),
  KEY `ExamSeries_sourceDocumentId_idx` (`sourceDocumentId`),
  CONSTRAINT `ExamSeries_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ExamSeries_sourceDocumentId_fkey` FOREIGN KEY (`sourceDocumentId`) REFERENCES `SourceDocument` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExamSeries`
--

LOCK TABLES `ExamSeries` WRITE;
/*!40000 ALTER TABLE `ExamSeries` DISABLE KEYS */;
INSERT INTO `ExamSeries` VALUES ('seed-series-aqa-summer-2026','Summer 2026',2026,'cmr0vive00003lz8bb9qnnjn7','2026-05-11 00:00:00.000','2026-06-26 00:00:00.000',NULL,'2026-06-30 16:41:21.837','2026-06-30 16:41:21.837'),('seed-series-cie-june-2026','June 2026',2026,'cmr0vive00002lz8bmcjz67k5','2026-04-28 00:00:00.000','2026-06-12 00:00:00.000',NULL,'2026-06-30 16:41:21.840','2026-06-30 16:41:21.840'),('seed-series-edexcel-summer-2026','Summer 2026',2026,'cmr0vive00001lz8bhenpgld7','2026-05-11 00:00:00.000','2026-06-26 00:00:00.000',NULL,'2026-06-30 16:41:21.843','2026-06-30 16:41:21.843');
/*!40000 ALTER TABLE `ExamSeries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExamSession`
--

DROP TABLE IF EXISTS `ExamSession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExamSession` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `startTime` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endTime` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `venue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paperId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceDocumentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ExamSession_paperId_idx` (`paperId`),
  KEY `ExamSession_examSeriesId_idx` (`examSeriesId`),
  KEY `ExamSession_date_idx` (`date`),
  KEY `ExamSession_sourceDocumentId_idx` (`sourceDocumentId`),
  CONSTRAINT `ExamSession_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ExamSession_paperId_fkey` FOREIGN KEY (`paperId`) REFERENCES `Paper` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ExamSession_sourceDocumentId_fkey` FOREIGN KEY (`sourceDocumentId`) REFERENCES `SourceDocument` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExamSession`
--

LOCK TABLES `ExamSession` WRITE;
/*!40000 ALTER TABLE `ExamSession` DISABLE KEYS */;
INSERT INTO `ExamSession` VALUES ('seed-session-aqa-maths-1','2026-05-19 01:00:00.000','09:00','10:30',NULL,'Main Hall',NULL,'seed-paper-aqa-maths-1','seed-series-aqa-summer-2026',NULL,'2026-06-30 16:41:21.846','2026-06-30 16:41:21.846'),('seed-session-aqa-maths-2','2026-06-04 05:00:00.000','13:00','14:30',NULL,'Sports Hall',NULL,'seed-paper-aqa-maths-2','seed-series-aqa-summer-2026',NULL,'2026-06-30 16:41:21.851','2026-06-30 16:41:21.851'),('seed-session-aqa-physics-1','2026-06-12 01:00:00.000','09:00','11:00',NULL,'Lab Block',NULL,'seed-paper-aqa-physics-1','seed-series-aqa-summer-2026',NULL,'2026-06-30 16:41:21.854','2026-06-30 16:41:21.854'),('seed-session-cie-maths-1','2026-05-08 01:00:00.000','09:00','11:00',NULL,'Hall A',NULL,'seed-paper-cie-maths-1','seed-series-cie-june-2026',NULL,'2026-06-30 16:41:21.856','2026-06-30 16:41:21.856'),('seed-session-edexcel-maths-1','2026-05-20 01:00:00.000','09:00','10:30',NULL,'Hall B',NULL,'seed-paper-edexcel-maths-1','seed-series-edexcel-summer-2026',NULL,'2026-06-30 16:41:21.858','2026-06-30 16:41:21.858');
/*!40000 ALTER TABLE `ExamSession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExchangeRate`
--

DROP TABLE IF EXISTS `ExchangeRate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ExchangeRate` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `baseCurrency` enum('GBP','CNY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetCurrency` enum('GBP','CNY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` decimal(12,4) NOT NULL,
  `effectiveDate` datetime(3) NOT NULL,
  `createdByUserId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ExchangeRate_registrationWindowId_idx` (`registrationWindowId`),
  KEY `ExchangeRate_baseCurrency_targetCurrency_idx` (`baseCurrency`,`targetCurrency`),
  KEY `ExchangeRate_effectiveDate_idx` (`effectiveDate`),
  KEY `ExchangeRate_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `ExchangeRate_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ExchangeRate_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExchangeRate`
--

LOCK TABLES `ExchangeRate` WRITE;
/*!40000 ALTER TABLE `ExchangeRate` DISABLE KEYS */;
/*!40000 ALTER TABLE `ExchangeRate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FeeAuditLog`
--

DROP TABLE IF EXISTS `FeeAuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FeeAuditLog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` enum('FEE_RULE_CREATED','FEE_RULE_UPDATED','EXCHANGE_RATE_UPDATED','FEE_STATEMENT_GENERATED','FEE_STATEMENT_BATCH_GENERATED','FEE_STATEMENT_PRINTED','FEE_SUMMARY_EXPORTED','FEE_DETAILS_EXPORTED','FEE_SCHEDULE_VERSION_CREATED','REGISTRATION_FEE_STATEMENT_GENERATED','POST_RESULTS_FEE_STATEMENT_GENERATED','FEE_STATEMENT_MARKED_NEEDS_REGENERATION','FEE_STATEMENT_REGENERATED_REVISED','FEE_STATEMENT_ISSUED','EXAM_ADDED','EXAM_REMOVED','EXAM_REPLACED','CANDIDATE_REGISTRATION_FEE_ADDED','CANDIDATE_REGISTRATION_FEE_REMOVED','ADDITIONAL_SERVICE_ADDED','ADDITIONAL_SERVICE_REMOVED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `performedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `metadata` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `FeeAuditLog_registrationWindowId_idx` (`registrationWindowId`),
  KEY `FeeAuditLog_performedByUserId_idx` (`performedByUserId`),
  KEY `FeeAuditLog_action_idx` (`action`),
  KEY `FeeAuditLog_performedAt_idx` (`performedAt`),
  CONSTRAINT `FeeAuditLog_performedByUserId_fkey` FOREIGN KEY (`performedByUserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeAuditLog_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FeeAuditLog`
--

LOCK TABLES `FeeAuditLog` WRITE;
/*!40000 ALTER TABLE `FeeAuditLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `FeeAuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FeeRule`
--

DROP TABLE IF EXISTS `FeeRule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FeeRule` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualificationId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paperId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examSessionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entryType` enum('NORMAL','LATE','HIGH_LATE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  `costCurrency` enum('GBP','CNY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `costAmount` decimal(12,2) NOT NULL,
  `exchangeRateToCny` decimal(12,4) DEFAULT NULL,
  `markupType` enum('PERCENTAGE','FIXED_AMOUNT','MANUAL') COLLATE utf8mb4_unicode_ci NOT NULL,
  `markupValue` decimal(12,2) DEFAULT NULL,
  `salesCurrency` enum('GBP','CNY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `salesAmount` decimal(12,2) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FeeRule_registrationWindowId_idx` (`registrationWindowId`),
  KEY `FeeRule_examBoardId_idx` (`examBoardId`),
  KEY `FeeRule_examSeriesId_idx` (`examSeriesId`),
  KEY `FeeRule_qualificationId_idx` (`qualificationId`),
  KEY `FeeRule_subjectId_idx` (`subjectId`),
  KEY `FeeRule_paperId_idx` (`paperId`),
  KEY `FeeRule_examSessionId_idx` (`examSessionId`),
  KEY `FeeRule_entryType_idx` (`entryType`),
  KEY `FeeRule_isActive_idx` (`isActive`),
  KEY `FeeRule_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `FeeRule_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeRule_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeRule_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeRule_examSessionId_fkey` FOREIGN KEY (`examSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeRule_paperId_fkey` FOREIGN KEY (`paperId`) REFERENCES `Paper` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeRule_qualificationId_fkey` FOREIGN KEY (`qualificationId`) REFERENCES `Qualification` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeRule_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeRule_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FeeRule`
--

LOCK TABLES `FeeRule` WRITE;
/*!40000 ALTER TABLE `FeeRule` DISABLE KEYS */;
/*!40000 ALTER TABLE `FeeRule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FeeSchedule`
--

DROP TABLE IF EXISTS `FeeSchedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FeeSchedule` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serviceType` enum('CANDIDATE_REGISTRATION','EXAM_ENTRY','REVIEW','PRIORITY_REVIEW','CLERICAL_CHECK','ACCESS_TO_SCRIPT','CASH_IN','CERTIFICATE','ADMINISTRATIVE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualificationId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paperId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entryType` enum('NORMAL','LATE','HIGH_LATE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` int NOT NULL,
  `effectiveFrom` datetime(3) NOT NULL,
  `effectiveTo` datetime(3) DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE','ARCHIVED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `costCurrency` enum('GBP','CNY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `costAmount` decimal(12,2) NOT NULL,
  `salesCurrency` enum('GBP','CNY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `salesAmount` decimal(12,2) NOT NULL,
  `markupType` enum('PERCENTAGE','FIXED_AMOUNT') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `markupValue` decimal(12,2) DEFAULT NULL,
  `exchangeRateToCny` decimal(12,4) DEFAULT NULL,
  `createdByUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FeeSchedule_examBoardId_idx` (`examBoardId`),
  KEY `FeeSchedule_serviceType_idx` (`serviceType`),
  KEY `FeeSchedule_status_idx` (`status`),
  KEY `FeeSchedule_effectiveFrom_effectiveTo_idx` (`effectiveFrom`,`effectiveTo`),
  KEY `FeeSchedule_version_idx` (`version`),
  KEY `FeeSchedule_qualificationId_fkey` (`qualificationId`),
  KEY `FeeSchedule_subjectId_fkey` (`subjectId`),
  KEY `FeeSchedule_paperId_fkey` (`paperId`),
  KEY `FeeSchedule_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `FeeSchedule_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeSchedule_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeSchedule_paperId_fkey` FOREIGN KEY (`paperId`) REFERENCES `Paper` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeSchedule_qualificationId_fkey` FOREIGN KEY (`qualificationId`) REFERENCES `Qualification` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeSchedule_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FeeSchedule`
--

LOCK TABLES `FeeSchedule` WRITE;
/*!40000 ALTER TABLE `FeeSchedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `FeeSchedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FeeStatement`
--

DROP TABLE IF EXISTS `FeeStatement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FeeStatement` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `studentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationWorkspaceId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statementNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayCurrency` enum('GBP','CNY','BOTH') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BOTH',
  `exchangeRateSnapshot` decimal(12,4) DEFAULT NULL,
  `studentNameSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentNoSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gradeSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classNameSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emailSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assessmentHubCandidateNumberSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `candidateTypeSnapshot` enum('INTERNAL','EXTERNAL') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('DRAFT','ISSUED','PAID','CANCELLED','REVISED','NEEDS_REGENERATION') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `totalGbpAmount` decimal(12,2) NOT NULL,
  `totalCnyAmount` decimal(12,2) NOT NULL,
  `paymentNotes` text COLLATE utf8mb4_unicode_ci,
  `generatedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `generatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `issuedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `statementKind` enum('NORMAL','RESTRICTED','EXTERNAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  `businessType` enum('REGISTRATION','POST_RESULTS') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REGISTRATION',
  `reviewWindowId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisedFromStatementId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisedToStatementId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regenerationReason` text COLLATE utf8mb4_unicode_ci,
  `regenerationChangedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regenerationChangedAt` datetime(3) DEFAULT NULL,
  `studentVisible` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `FeeStatement_statementNo_key` (`statementNo`),
  KEY `FeeStatement_candidateId_idx` (`candidateId`),
  KEY `FeeStatement_studentId_idx` (`studentId`),
  KEY `FeeStatement_registrationWorkspaceId_idx` (`registrationWorkspaceId`),
  KEY `FeeStatement_registrationWindowId_idx` (`registrationWindowId`),
  KEY `FeeStatement_status_idx` (`status`),
  KEY `FeeStatement_statementNo_idx` (`statementNo`),
  KEY `FeeStatement_generatedByUserId_fkey` (`generatedByUserId`),
  KEY `FeeStatement_statementKind_idx` (`statementKind`),
  KEY `FeeStatement_reviewWindowId_idx` (`reviewWindowId`),
  KEY `FeeStatement_businessType_idx` (`businessType`),
  KEY `FeeStatement_revisedFromStatementId_idx` (`revisedFromStatementId`),
  KEY `FeeStatement_revisedToStatementId_idx` (`revisedToStatementId`),
  KEY `FeeStatement_regenerationChangedByUserId_idx` (`regenerationChangedByUserId`),
  CONSTRAINT `FeeStatement_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeStatement_generatedByUserId_fkey` FOREIGN KEY (`generatedByUserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeStatement_regenerationChangedByUserId_fkey` FOREIGN KEY (`regenerationChangedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeStatement_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeStatement_registrationWorkspaceId_fkey` FOREIGN KEY (`registrationWorkspaceId`) REFERENCES `RegistrationWorkspace` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeStatement_reviewWindowId_fkey` FOREIGN KEY (`reviewWindowId`) REFERENCES `ReviewWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FeeStatement_revisedFromStatementId_fkey` FOREIGN KEY (`revisedFromStatementId`) REFERENCES `FeeStatement` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeStatement_revisedToStatementId_fkey` FOREIGN KEY (`revisedToStatementId`) REFERENCES `FeeStatement` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeStatement_studentId_fkey` FOREIGN KEY (`studentId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FeeStatement`
--

LOCK TABLES `FeeStatement` WRITE;
/*!40000 ALTER TABLE `FeeStatement` DISABLE KEYS */;
/*!40000 ALTER TABLE `FeeStatement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FeeStatementItem`
--

DROP TABLE IF EXISTS `FeeStatementItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FeeStatementItem` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feeStatementId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSessionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examBoardSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualificationSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subjectSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paperCodeSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paperTitleSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entryTypeSnapshot` enum('NORMAL','LATE','HIGH_LATE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `costCurrencySnapshot` enum('GBP','CNY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `costAmountSnapshot` decimal(12,2) NOT NULL,
  `exchangeRateSnapshot` decimal(12,4) DEFAULT NULL,
  `markupTypeSnapshot` enum('PERCENTAGE','FIXED_AMOUNT') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `markupValueSnapshot` decimal(12,2) DEFAULT NULL,
  `salesGbpAmountSnapshot` decimal(12,2) DEFAULT NULL,
  `salesCnyAmountSnapshot` decimal(12,2) DEFAULT NULL,
  `displayCurrencySnapshot` enum('GBP','CNY','BOTH') COLLATE utf8mb4_unicode_ci NOT NULL,
  `lineTotalGbp` decimal(12,2) NOT NULL,
  `lineTotalCny` decimal(12,2) NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `serviceType` enum('CANDIDATE_REGISTRATION','EXAM_ENTRY','REVIEW','PRIORITY_REVIEW','CLERICAL_CHECK','ACCESS_TO_SCRIPT','CASH_IN','CERTIFICATE','ADMINISTRATIVE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feeScheduleId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feeScheduleVersionSnapshot` int DEFAULT NULL,
  `serviceNameSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesCurrencySnapshot` enum('GBP','CNY') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesAmountSnapshot` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FeeStatementItem_feeStatementId_idx` (`feeStatementId`),
  KEY `FeeStatementItem_examSessionId_idx` (`examSessionId`),
  KEY `FeeStatementItem_feeScheduleId_idx` (`feeScheduleId`),
  KEY `FeeStatementItem_serviceType_idx` (`serviceType`),
  CONSTRAINT `FeeStatementItem_examSessionId_fkey` FOREIGN KEY (`examSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeStatementItem_feeScheduleId_fkey` FOREIGN KEY (`feeScheduleId`) REFERENCES `FeeSchedule` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FeeStatementItem_feeStatementId_fkey` FOREIGN KEY (`feeStatementId`) REFERENCES `FeeStatement` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FeeStatementItem`
--

LOCK TABLES `FeeStatementItem` WRITE;
/*!40000 ALTER TABLE `FeeStatementItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `FeeStatementItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KeyDate`
--

DROP TABLE IF EXISTS `KeyDate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KeyDate` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `type` enum('DEADLINE','RESULTS','REGISTRATION','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OTHER',
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceDocumentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `KeyDate_date_idx` (`date`),
  KEY `KeyDate_examBoardId_idx` (`examBoardId`),
  KEY `KeyDate_subjectId_idx` (`subjectId`),
  KEY `KeyDate_examSeriesId_idx` (`examSeriesId`),
  KEY `KeyDate_sourceDocumentId_idx` (`sourceDocumentId`),
  CONSTRAINT `KeyDate_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `KeyDate_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `KeyDate_sourceDocumentId_fkey` FOREIGN KEY (`sourceDocumentId`) REFERENCES `SourceDocument` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `KeyDate_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KeyDate`
--

LOCK TABLES `KeyDate` WRITE;
/*!40000 ALTER TABLE `KeyDate` DISABLE KEYS */;
INSERT INTO `KeyDate` VALUES ('seed-keydate-aqa-entry','Final Entry Deadline','2026-02-21 00:00:00.000','DEADLINE','Last date to submit candidate entries',NULL,'cmr0vive00003lz8bb9qnnjn7',NULL,'seed-series-aqa-summer-2026',NULL,'2026-06-30 16:41:21.860','2026-06-30 16:41:21.860'),('seed-keydate-aqa-results','GCSE Results Day','2026-08-20 00:00:00.000','RESULTS','Results released to centres',NULL,'cmr0vive00003lz8bb9qnnjn7',NULL,'seed-series-aqa-summer-2026',NULL,'2026-06-30 16:41:21.864','2026-06-30 16:41:21.864'),('seed-keydate-cie-entry','Late Entry Deadline','2026-03-01 00:00:00.000','DEADLINE','Final late entry date for June series',NULL,'cmr0vive00002lz8bmcjz67k5',NULL,'seed-series-cie-june-2026',NULL,'2026-06-30 16:41:21.867','2026-06-30 16:41:21.867'),('seed-keydate-edexcel-results','Results Day','2026-08-20 00:00:00.000','RESULTS','Summer results released',NULL,'cmr0vive00001lz8bhenpgld7',NULL,'seed-series-edexcel-summer-2026',NULL,'2026-06-30 16:41:21.870','2026-06-30 16:41:21.870');
/*!40000 ALTER TABLE `KeyDate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Paper`
--

DROP TABLE IF EXISTS `Paper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Paper` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` int DEFAULT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceDocumentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Paper_subjectId_idx` (`subjectId`),
  KEY `Paper_sourceDocumentId_idx` (`sourceDocumentId`),
  CONSTRAINT `Paper_sourceDocumentId_fkey` FOREIGN KEY (`sourceDocumentId`) REFERENCES `SourceDocument` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Paper_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Paper`
--

LOCK TABLES `Paper` WRITE;
/*!40000 ALTER TABLE `Paper` DISABLE KEYS */;
INSERT INTO `Paper` VALUES ('seed-paper-aqa-maths-1','8300/1F','Paper 1 Foundation',90,'seed-subject-aqa-maths',NULL,'2026-06-30 16:41:21.823','2026-06-30 16:41:21.823'),('seed-paper-aqa-maths-2','8300/2F','Paper 2 Foundation',90,'seed-subject-aqa-maths',NULL,'2026-06-30 16:41:21.826','2026-06-30 16:41:21.826'),('seed-paper-aqa-physics-1','7408/1','Paper 1',120,'seed-subject-aqa-physics',NULL,'2026-06-30 16:41:21.828','2026-06-30 16:41:21.828'),('seed-paper-cie-maths-1','0580/21','Paper 2 (Extended)',120,'seed-subject-cie-maths',NULL,'2026-06-30 16:41:21.830','2026-06-30 16:41:21.830'),('seed-paper-edexcel-maths-1','1MA1/1F','Paper 1 Foundation (Non-Calculator)',90,'seed-subject-edexcel-maths',NULL,'2026-06-30 16:41:21.834','2026-06-30 16:41:21.834');
/*!40000 ALTER TABLE `Paper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PasswordResetToken`
--

DROP TABLE IF EXISTS `PasswordResetToken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PasswordResetToken` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenHash` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `usedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PasswordResetToken_tokenHash_key` (`tokenHash`),
  KEY `PasswordResetToken_userId_idx` (`userId`),
  KEY `PasswordResetToken_expiresAt_idx` (`expiresAt`),
  CONSTRAINT `PasswordResetToken_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PasswordResetToken`
--

LOCK TABLES `PasswordResetToken` WRITE;
/*!40000 ALTER TABLE `PasswordResetToken` DISABLE KEYS */;
/*!40000 ALTER TABLE `PasswordResetToken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PostResultsAuditLog`
--

DROP TABLE IF EXISTS `PostResultsAuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PostResultsAuditLog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` enum('REVIEW_WINDOW_CREATED','REVIEW_WINDOW_UPDATED','REVIEW_WINDOW_LOCKED','REVIEW_SERVICE_ENABLED','REVIEW_SERVICE_DISABLED','REVIEW_REQUEST_CREATED','REVIEW_REQUEST_UPDATED','REVIEW_REQUEST_SUBMITTED','CASH_IN_REQUEST_CREATED','ACCESS_TO_SCRIPT_REQUEST_CREATED','CERTIFICATE_REQUEST_CREATED','FEE_SCHEDULE_VERSION_CREATED','REGISTRATION_FEE_STATEMENT_GENERATED','POST_RESULTS_FEE_STATEMENT_GENERATED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewWindowId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serviceType` enum('CANDIDATE_REGISTRATION','EXAM_ENTRY','REVIEW','PRIORITY_REVIEW','CLERICAL_CHECK','ACCESS_TO_SCRIPT','CASH_IN','CERTIFICATE','ADMINISTRATIVE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `performedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `reason` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `metadata` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `PostResultsAuditLog_reviewWindowId_idx` (`reviewWindowId`),
  KEY `PostResultsAuditLog_registrationWindowId_idx` (`registrationWindowId`),
  KEY `PostResultsAuditLog_candidateId_idx` (`candidateId`),
  KEY `PostResultsAuditLog_examBoardId_idx` (`examBoardId`),
  KEY `PostResultsAuditLog_action_idx` (`action`),
  KEY `PostResultsAuditLog_performedAt_idx` (`performedAt`),
  KEY `PostResultsAuditLog_examSeriesId_fkey` (`examSeriesId`),
  KEY `PostResultsAuditLog_performedByUserId_fkey` (`performedByUserId`),
  CONSTRAINT `PostResultsAuditLog_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `PostResultsAuditLog_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `PostResultsAuditLog_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `PostResultsAuditLog_performedByUserId_fkey` FOREIGN KEY (`performedByUserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PostResultsAuditLog_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `PostResultsAuditLog_reviewWindowId_fkey` FOREIGN KEY (`reviewWindowId`) REFERENCES `ReviewWindow` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PostResultsAuditLog`
--

LOCK TABLES `PostResultsAuditLog` WRITE;
/*!40000 ALTER TABLE `PostResultsAuditLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `PostResultsAuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Qualification`
--

DROP TABLE IF EXISTS `Qualification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Qualification` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Qualification_examBoardId_idx` (`examBoardId`),
  CONSTRAINT `Qualification_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Qualification`
--

LOCK TABLES `Qualification` WRITE;
/*!40000 ALTER TABLE `Qualification` DISABLE KEYS */;
INSERT INTO `Qualification` VALUES ('seed-qual-aqa-alevel-physics','A-Level Physics','A-Level','7408','cmr0vive00003lz8bb9qnnjn7','2026-06-30 16:41:21.803','2026-06-30 16:41:21.803'),('seed-qual-aqa-gcse-maths','GCSE Mathematics','GCSE','8300','cmr0vive00003lz8bb9qnnjn7','2026-06-30 16:41:21.799','2026-06-30 16:41:21.799'),('seed-qual-cie-igcse-maths','IGCSE Mathematics','IGCSE','0580','cmr0vive00002lz8bmcjz67k5','2026-06-30 16:41:21.807','2026-06-30 16:41:21.807'),('seed-qual-edexcel-gcse-maths','GCSE Mathematics','GCSE','1MA1','cmr0vive00001lz8bhenpgld7','2026-06-30 16:41:21.810','2026-06-30 16:41:21.810');
/*!40000 ALTER TABLE `Qualification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistrationAuditLog`
--

DROP TABLE IF EXISTS `RegistrationAuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RegistrationAuditLog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationWorkspaceId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `studentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examSessionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` enum('ADD','REMOVE','SUBMIT','UPDATE','CANCEL','LOCK','ADMIN_ADJUST','STUDENT_ADD','STUDENT_REMOVE','STUDENT_SUBMIT','SYSTEM_LOCK','EO_ADD_AFTER_LOCK','EO_REMOVE_AFTER_LOCK','EO_REPLACE_AFTER_LOCK','ADMIN_ADD_AFTER_LOCK','ADMIN_REMOVE_AFTER_LOCK','ADMIN_REPLACE_AFTER_LOCK','TEACHER_CHANGE_REQUEST','TEACHER_REQUEST_APPROVED','TEACHER_REQUEST_REJECTED','TEACHER_LATE_REGISTRATION_REQUEST','TEACHER_LATE_REGISTRATION_APPROVED','TEACHER_LATE_REGISTRATION_REJECTED','EO_LATE_REGISTRATION_CREATED','ADMIN_LATE_REGISTRATION_CREATED','EO_ASSISTED_REGISTRATION_CREATED','ADMIN_ASSISTED_REGISTRATION_CREATED','INTERNAL_NORMAL_REGISTRATION_CREATED','RESTRICTED_INTERNAL_REGISTRATION_CREATED','EXTERNAL_REGISTRATION_CREATED','INTERNAL_NORMAL_REGISTRATION_UPDATED','RESTRICTED_INTERNAL_REGISTRATION_UPDATED','EXTERNAL_REGISTRATION_UPDATED','EO_OFFICE_ONLY_REGISTRATION_CREATED','ADMIN_OFFICE_ONLY_REGISTRATION_CREATED','EO_RESTRICTED_REGISTRATION_CREATED','ADMIN_RESTRICTED_REGISTRATION_CREATED','RESTRICTED_REGISTRATION_UPDATED','RESTRICTED_REGISTRATION_CANCELLED','EO_POST_LOCK_ADJUSTMENT','ADMIN_POST_LOCK_ADJUSTMENT','STUDENT_REGISTRATION_SUBMITTED','EXTERNAL_CANDIDATE_REGISTRATION_CREATED','REGISTRATION_STAGE_CREATED','REGISTRATION_STAGE_UPDATED','REGISTRATION_STAGE_DISABLED','FEE_STAGE_CREATED','FEE_STAGE_UPDATED','STUDENT_REGISTRATION_OPENED','STUDENT_REGISTRATION_CLOSED','REGISTRATION_WINDOW_CLOSED','ENTRY_TYPE_AUTO_ASSIGNED','ENTRY_TYPE_OVERRIDDEN','ENTRY_TYPE_DEFAULTED_TO_NORMAL','POST_STUDENT_CLOSE_ADJUSTMENT','POST_WINDOW_CLOSE_OVERRIDE','CANDIDATE_REGISTRATION_FEE_ADDED','CANDIDATE_REGISTRATION_FEE_REMOVED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `performedById` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `performedByRole` enum('ADMIN','EXAM_OFFICER','SUBJECT_TEACHER','STUDENT') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `beforeValue` text COLLATE utf8mb4_unicode_ci,
  `afterValue` text COLLATE utf8mb4_unicode_ci,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `registrationSource` enum('STUDENT_SUBMITTED','TEACHER_REQUEST_APPROVED','EO_ASSISTED','ADMIN_ASSISTED','EO_FORCED_INTERNAL','ADMIN_FORCED_INTERNAL','EO_POST_LOCK_ADJUSTMENT','ADMIN_POST_LOCK_ADJUSTMENT','EXTERNAL_CANDIDATE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visibility` enum('STUDENT_AND_TEACHER','STUDENT_ONLY','EXAM_OFFICE_ONLY') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billingScope` enum('NORMAL_BILLING','RESTRICTED_BILLING','EXTERNAL_BILLING','NO_BILLING','MANUAL_REVIEW') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assessmentHubCandidateNumberSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `candidateTypeSnapshot` enum('INTERNAL','EXTERNAL') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `entryType` enum('NORMAL','LATE','HIGH_LATE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feeStageId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationType` enum('INTERNAL_NORMAL','RESTRICTED_INTERNAL','EXTERNAL') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feeStatementNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issueNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `RegistrationAuditLog_registrationWorkspaceId_idx` (`registrationWorkspaceId`),
  KEY `RegistrationAuditLog_candidateId_idx` (`candidateId`),
  KEY `RegistrationAuditLog_studentId_idx` (`studentId`),
  KEY `RegistrationAuditLog_registrationId_idx` (`registrationId`),
  KEY `RegistrationAuditLog_examSessionId_idx` (`examSessionId`),
  KEY `RegistrationAuditLog_performedById_idx` (`performedById`),
  KEY `RegistrationAuditLog_performedAt_idx` (`performedAt`),
  KEY `RegistrationAuditLog_registrationWindowId_idx` (`registrationWindowId`),
  KEY `RegistrationAuditLog_feeStageId_idx` (`feeStageId`),
  KEY `RegistrationAuditLog_registrationType_idx` (`registrationType`),
  CONSTRAINT `RegistrationAuditLog_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationAuditLog_examSessionId_fkey` FOREIGN KEY (`examSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationAuditLog_feeStageId_fkey` FOREIGN KEY (`feeStageId`) REFERENCES `RegistrationFeeStage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationAuditLog_performedById_fkey` FOREIGN KEY (`performedById`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationAuditLog_registrationId_fkey` FOREIGN KEY (`registrationId`) REFERENCES `StudentExamRegistration` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationAuditLog_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationAuditLog_registrationWorkspaceId_fkey` FOREIGN KEY (`registrationWorkspaceId`) REFERENCES `RegistrationWorkspace` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationAuditLog_studentId_fkey` FOREIGN KEY (`studentId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistrationAuditLog`
--

LOCK TABLES `RegistrationAuditLog` WRITE;
/*!40000 ALTER TABLE `RegistrationAuditLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `RegistrationAuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistrationChangeRequest`
--

DROP TABLE IF EXISTS `RegistrationChangeRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RegistrationChangeRequest` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationWorkspaceId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `studentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestedByRole` enum('ADMIN','EXAM_OFFICER','SUBJECT_TEACHER','STUDENT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestType` enum('ADD_EXAM','REMOVE_EXAM','REPLACE_EXAM','LATE_REGISTRATION') COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetExamSessionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `targetRegistrationId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replacementExamSessionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('PENDING','APPROVED','REJECTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `reviewedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewedAt` datetime(3) DEFAULT NULL,
  `reviewNote` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `RegistrationChangeRequest_registrationWorkspaceId_idx` (`registrationWorkspaceId`),
  KEY `RegistrationChangeRequest_registrationWindowId_idx` (`registrationWindowId`),
  KEY `RegistrationChangeRequest_candidateId_idx` (`candidateId`),
  KEY `RegistrationChangeRequest_studentId_idx` (`studentId`),
  KEY `RegistrationChangeRequest_requestedByUserId_idx` (`requestedByUserId`),
  KEY `RegistrationChangeRequest_status_idx` (`status`),
  KEY `RegistrationChangeRequest_targetExamSessionId_fkey` (`targetExamSessionId`),
  KEY `RegistrationChangeRequest_replacementExamSessionId_fkey` (`replacementExamSessionId`),
  KEY `RegistrationChangeRequest_reviewedByUserId_fkey` (`reviewedByUserId`),
  CONSTRAINT `RegistrationChangeRequest_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationChangeRequest_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationChangeRequest_registrationWorkspaceId_fkey` FOREIGN KEY (`registrationWorkspaceId`) REFERENCES `RegistrationWorkspace` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationChangeRequest_replacementExamSessionId_fkey` FOREIGN KEY (`replacementExamSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationChangeRequest_requestedByUserId_fkey` FOREIGN KEY (`requestedByUserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationChangeRequest_reviewedByUserId_fkey` FOREIGN KEY (`reviewedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationChangeRequest_studentId_fkey` FOREIGN KEY (`studentId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationChangeRequest_targetExamSessionId_fkey` FOREIGN KEY (`targetExamSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistrationChangeRequest`
--

LOCK TABLES `RegistrationChangeRequest` WRITE;
/*!40000 ALTER TABLE `RegistrationChangeRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `RegistrationChangeRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistrationChangeRequestExamSession`
--

DROP TABLE IF EXISTS `RegistrationChangeRequestExamSession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RegistrationChangeRequestExamSession` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changeRequestId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSessionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `RegistrationChangeRequestExamSession_changeRequestId_examSes_key` (`changeRequestId`,`examSessionId`),
  KEY `RegistrationChangeRequestExamSession_changeRequestId_idx` (`changeRequestId`),
  KEY `RegistrationChangeRequestExamSession_examSessionId_idx` (`examSessionId`),
  CONSTRAINT `RegistrationChangeRequestExamSession_changeRequestId_fkey` FOREIGN KEY (`changeRequestId`) REFERENCES `RegistrationChangeRequest` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationChangeRequestExamSession_examSessionId_fkey` FOREIGN KEY (`examSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistrationChangeRequestExamSession`
--

LOCK TABLES `RegistrationChangeRequestExamSession` WRITE;
/*!40000 ALTER TABLE `RegistrationChangeRequestExamSession` DISABLE KEYS */;
/*!40000 ALTER TABLE `RegistrationChangeRequestExamSession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistrationFeeStage`
--

DROP TABLE IF EXISTS `RegistrationFeeStage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RegistrationFeeStage` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stageCode` enum('NORMAL','LATE','HIGH_LATE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `stageName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence` int NOT NULL,
  `startAt` datetime(3) NOT NULL,
  `endAt` datetime(3) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RegistrationStage_registrationWindowId_stageCode_key` (`registrationWindowId`,`stageCode`),
  KEY `RegistrationStage_registrationWindowId_idx` (`registrationWindowId`),
  KEY `RegistrationStage_enabled_idx` (`enabled`),
  KEY `RegistrationStage_sequence_idx` (`sequence`),
  CONSTRAINT `RegistrationStage_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistrationFeeStage`
--

LOCK TABLES `RegistrationFeeStage` WRITE;
/*!40000 ALTER TABLE `RegistrationFeeStage` DISABLE KEYS */;
INSERT INTO `RegistrationFeeStage` VALUES ('cmr0vix97000rlz8b7tk4qq70','seed-window-aqa-summer','NORMAL','Normal',1,'2026-01-01 00:00:00.000','2026-05-02 07:59:59.999',1,NULL,'2026-06-30 16:41:24.188','2026-06-30 16:41:24.188'),('cmr0vix9e000tlz8b2av82w89','seed-window-aqa-summer','LATE','Late',2,'2026-05-02 08:00:00.000','2026-08-31 15:59:59.999',1,NULL,'2026-06-30 16:41:24.195','2026-06-30 16:41:24.195'),('cmr0vix9h000vlz8b3cw66g5l','seed-window-aqa-summer','HIGH_LATE','High Late',3,'2026-08-31 16:00:00.000','2026-12-31 00:00:00.000',1,NULL,'2026-06-30 16:41:24.198','2026-06-30 16:41:24.198'),('cmr0vix9k000xlz8bcfgp8sep','seed-window-cie-june','NORMAL','Normal',1,'2026-01-01 00:00:00.000','2026-05-02 07:59:59.999',1,NULL,'2026-06-30 16:41:24.200','2026-06-30 16:41:24.200'),('cmr0vix9o000zlz8b8iitk0r3','seed-window-cie-june','LATE','Late',2,'2026-05-02 08:00:00.000','2026-08-31 15:59:59.999',1,NULL,'2026-06-30 16:41:24.205','2026-06-30 16:41:24.205'),('cmr0vix9r0011lz8bbtrptc54','seed-window-cie-june','HIGH_LATE','High Late',3,'2026-08-31 16:00:00.000','2026-12-31 00:00:00.000',1,NULL,'2026-06-30 16:41:24.208','2026-06-30 16:41:24.208'),('cmr0vix9u0013lz8bnzt7vvd4','seed-window-edexcel-summer','NORMAL','Normal',1,'2026-01-01 00:00:00.000','2026-05-02 07:59:59.999',1,NULL,'2026-06-30 16:41:24.210','2026-06-30 16:41:24.210'),('cmr0vix9y0015lz8b7j0phlh5','seed-window-edexcel-summer','LATE','Late',2,'2026-05-02 08:00:00.000','2026-08-31 15:59:59.999',1,NULL,'2026-06-30 16:41:24.215','2026-06-30 16:41:24.215'),('cmr0vixa30017lz8ba9qt0aon','seed-window-edexcel-summer','HIGH_LATE','High Late',3,'2026-08-31 16:00:00.000','2026-12-31 00:00:00.000',1,NULL,'2026-06-30 16:41:24.220','2026-06-30 16:41:24.220'),('cmr0vixa70019lz8bj5ueiaag','seed-window-summer-2026-all','NORMAL','Normal',1,'2026-01-01 00:00:00.000','2026-05-02 07:59:59.999',1,NULL,'2026-06-30 16:41:24.223','2026-06-30 16:41:24.223'),('cmr0vixaa001blz8bigx4owz2','seed-window-summer-2026-all','LATE','Late',2,'2026-05-02 08:00:00.000','2026-08-31 15:59:59.999',1,NULL,'2026-06-30 16:41:24.227','2026-06-30 16:41:24.227'),('cmr0vixad001dlz8bxeusdf5b','seed-window-summer-2026-all','HIGH_LATE','High Late',3,'2026-08-31 16:00:00.000','2026-12-31 00:00:00.000',1,NULL,'2026-06-30 16:41:24.230','2026-06-30 16:41:24.230');
/*!40000 ALTER TABLE `RegistrationFeeStage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistrationWindow`
--

DROP TABLE IF EXISTS `RegistrationWindow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RegistrationWindow` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('DRAFT','OPEN','CLOSED','ARCHIVED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `eoAssistedRegistrationEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `officeOnlyRegistrationEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `postLockAdjustmentEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `studentSelfRegistrationEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `studentRegistrationOpenAt` datetime(3) NOT NULL,
  `studentRegistrationCloseAt` datetime(3) NOT NULL,
  `registrationCloseAt` datetime(3) NOT NULL,
  `academicYear` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `RegistrationWindow_examBoardId_idx` (`examBoardId`),
  KEY `RegistrationWindow_examSeriesId_idx` (`examSeriesId`),
  KEY `RegistrationWindow_status_idx` (`status`),
  KEY `RegistrationWindow_createdById_fkey` (`createdById`),
  KEY `RegistrationWindow_timing_idx` (`studentRegistrationOpenAt`,`studentRegistrationCloseAt`,`registrationCloseAt`),
  KEY `RegistrationWindow_academicYear_idx` (`academicYear`),
  CONSTRAINT `RegistrationWindow_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationWindow_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationWindow_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistrationWindow`
--

LOCK TABLES `RegistrationWindow` WRITE;
/*!40000 ALTER TABLE `RegistrationWindow` DISABLE KEYS */;
INSERT INTO `RegistrationWindow` VALUES ('seed-window-aqa-summer','cmr0vive00003lz8bb9qnnjn7','seed-series-aqa-summer-2026','AQA Summer 2026 Registration','OPEN','cmr0vivda0000lz8bmmywok09','2026-06-30 16:41:24.150','2026-06-30 16:41:24.150',1,1,1,1,'2026-01-01 00:00:00.000','2026-09-30 00:00:00.000','2026-12-31 00:00:00.000','2025/26'),('seed-window-cie-june','cmr0vive00002lz8bmcjz67k5','seed-series-cie-june-2026','Cambridge June 2026 Registration','OPEN','cmr0vivda0000lz8bmmywok09','2026-06-30 16:41:24.158','2026-06-30 16:41:24.158',1,1,1,1,'2026-01-01 00:00:00.000','2026-09-30 00:00:00.000','2026-12-31 00:00:00.000','2025/26'),('seed-window-edexcel-summer','cmr0vive00001lz8bhenpgld7','seed-series-edexcel-summer-2026','Edexcel Summer 2026 Registration','OPEN','cmr0vivda0000lz8bmmywok09','2026-06-30 16:41:24.167','2026-06-30 16:41:24.167',1,1,1,1,'2026-01-01 00:00:00.000','2026-09-30 00:00:00.000','2026-12-31 00:00:00.000','2025/26'),('seed-window-summer-2026-all','cmr0vive00001lz8bhenpgld7','seed-series-edexcel-summer-2026','Summer 2026 Multi-Board Registration','OPEN','cmr0vivda0000lz8bmmywok09','2026-06-30 16:41:24.174','2026-06-30 16:41:24.174',1,1,1,1,'2026-01-01 00:00:00.000','2026-09-30 00:00:00.000','2026-12-31 00:00:00.000','2025/26');
/*!40000 ALTER TABLE `RegistrationWindow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistrationWindowIncludedSeries`
--

DROP TABLE IF EXISTS `RegistrationWindowIncludedSeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RegistrationWindowIncludedSeries` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `rw_included_series_uq` (`registrationWindowId`,`examSeriesId`),
  KEY `RegistrationWindowIncludedSeries_examSeriesId_idx` (`examSeriesId`),
  CONSTRAINT `RegistrationWindowIncludedSeries_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationWindowIncludedSeries_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistrationWindowIncludedSeries`
--

LOCK TABLES `RegistrationWindowIncludedSeries` WRITE;
/*!40000 ALTER TABLE `RegistrationWindowIncludedSeries` DISABLE KEYS */;
INSERT INTO `RegistrationWindowIncludedSeries` VALUES ('cmr0vix8b000flz8bszz1mk3e','seed-window-aqa-summer','seed-series-aqa-summer-2026','2026-06-30 16:41:24.156'),('cmr0vix8j000hlz8bt6pw6592','seed-window-cie-june','seed-series-cie-june-2026','2026-06-30 16:41:24.164'),('cmr0vix8r000jlz8b9fyezudh','seed-window-edexcel-summer','seed-series-edexcel-summer-2026','2026-06-30 16:41:24.171'),('cmr0vix8x000llz8bx40f25cw','seed-window-summer-2026-all','seed-series-edexcel-summer-2026','2026-06-30 16:41:24.178'),('cmr0vix8z000nlz8bro85tjaa','seed-window-summer-2026-all','seed-series-cie-june-2026','2026-06-30 16:41:24.180'),('cmr0vix93000plz8bobwnvw12','seed-window-summer-2026-all','seed-series-aqa-summer-2026','2026-06-30 16:41:24.183');
/*!40000 ALTER TABLE `RegistrationWindowIncludedSeries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RegistrationWorkspace`
--

DROP TABLE IF EXISTS `RegistrationWorkspace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RegistrationWorkspace` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `studentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockedAt` datetime(3) DEFAULT NULL,
  `lastAdjustedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastAdjustedByRole` enum('ADMIN','EXAM_OFFICER','SUBJECT_TEACHER','STUDENT') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastAdjustedAt` datetime(3) DEFAULT NULL,
  `lastAdjustmentReason` text COLLATE utf8mb4_unicode_ci,
  `lastAdjustmentSummary` text COLLATE utf8mb4_unicode_ci,
  `hasPostLockAdjustment` tinyint(1) NOT NULL DEFAULT '0',
  `isLateRegistration` tinyint(1) NOT NULL DEFAULT '0',
  `registrationSource` enum('STUDENT_SUBMITTED','TEACHER_REQUEST_APPROVED','EO_ASSISTED','ADMIN_ASSISTED','EO_FORCED_INTERNAL','ADMIN_FORCED_INTERNAL','EO_POST_LOCK_ADJUSTMENT','ADMIN_POST_LOCK_ADJUSTMENT','EXTERNAL_CANDIDATE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'STUDENT_SUBMITTED',
  `visibility` enum('STUDENT_AND_TEACHER','STUDENT_ONLY','EXAM_OFFICE_ONLY') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'STUDENT_AND_TEACHER',
  `billingScope` enum('NORMAL_BILLING','RESTRICTED_BILLING','EXTERNAL_BILLING','NO_BILLING','MANUAL_REVIEW') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL_BILLING',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `entryType` enum('NORMAL','LATE','HIGH_LATE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  `entryTypeOverridden` tinyint(1) NOT NULL DEFAULT '0',
  `entryTypeOverrideReason` text COLLATE utf8mb4_unicode_ci,
  `feeStageId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationType` enum('INTERNAL_NORMAL','RESTRICTED_INTERNAL','EXTERNAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INTERNAL_NORMAL',
  `visibleToStudent` tinyint(1) NOT NULL DEFAULT '1',
  `visibleToTeacher` tinyint(1) NOT NULL DEFAULT '1',
  `visibleInStudentPortal` tinyint(1) NOT NULL DEFAULT '1',
  `visibleInTeacherPortal` tinyint(1) NOT NULL DEFAULT '1',
  `visibleInStudentDocuments` tinyint(1) NOT NULL DEFAULT '1',
  `visibleInStudentBilling` tinyint(1) NOT NULL DEFAULT '1',
  `restrictedReason` text COLLATE utf8mb4_unicode_ci,
  `restrictedCreatedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restrictedCreatedAt` datetime(3) DEFAULT NULL,
  `restrictedUpdatedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restrictedUpdatedAt` datetime(3) DEFAULT NULL,
  `includeCandidateRegistrationFee` tinyint(1) NOT NULL DEFAULT '0',
  `registrationNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `confirmationNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RegistrationWorkspace_candidateId_registrationWindowId_key` (`candidateId`,`registrationWindowId`),
  UNIQUE KEY `RegistrationWorkspace_studentId_registrationWindowId_key` (`studentId`,`registrationWindowId`),
  UNIQUE KEY `rw_candidate_window_type_uq` (`candidateId`,`registrationWindowId`,`registrationType`),
  UNIQUE KEY `rw_student_window_type_uq` (`studentId`,`registrationWindowId`,`registrationType`),
  UNIQUE KEY `RegistrationWorkspace_registrationNumber_key` (`registrationNumber`),
  UNIQUE KEY `RegistrationWorkspace_confirmationNumber_key` (`confirmationNumber`),
  KEY `RegistrationWorkspace_candidateId_idx` (`candidateId`),
  KEY `RegistrationWorkspace_studentId_idx` (`studentId`),
  KEY `RegistrationWorkspace_registrationWindowId_idx` (`registrationWindowId`),
  KEY `RegistrationWorkspace_hasPostLockAdjustment_idx` (`hasPostLockAdjustment`),
  KEY `RegistrationWorkspace_registrationSource_idx` (`registrationSource`),
  KEY `RegistrationWorkspace_visibility_idx` (`visibility`),
  KEY `RegistrationWorkspace_billingScope_idx` (`billingScope`),
  KEY `RegistrationWorkspace_lastAdjustedByUserId_fkey` (`lastAdjustedByUserId`),
  KEY `RegistrationWorkspace_entryType_idx` (`entryType`),
  KEY `RegistrationWorkspace_feeStageId_idx` (`feeStageId`),
  KEY `RegistrationWorkspace_restrictedCreatedById_fkey` (`restrictedCreatedById`),
  KEY `RegistrationWorkspace_restrictedUpdatedById_fkey` (`restrictedUpdatedById`),
  KEY `RegistrationWorkspace_registrationType_idx` (`registrationType`),
  CONSTRAINT `RegistrationWorkspace_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationWorkspace_feeStageId_fkey` FOREIGN KEY (`feeStageId`) REFERENCES `RegistrationFeeStage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationWorkspace_lastAdjustedByUserId_fkey` FOREIGN KEY (`lastAdjustedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationWorkspace_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RegistrationWorkspace_restrictedCreatedById_fkey` FOREIGN KEY (`restrictedCreatedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationWorkspace_restrictedUpdatedById_fkey` FOREIGN KEY (`restrictedUpdatedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `RegistrationWorkspace_studentId_fkey` FOREIGN KEY (`studentId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RegistrationWorkspace`
--

LOCK TABLES `RegistrationWorkspace` WRITE;
/*!40000 ALTER TABLE `RegistrationWorkspace` DISABLE KEYS */;
/*!40000 ALTER TABLE `RegistrationWorkspace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Resource`
--

DROP TABLE IF EXISTS `Resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Resource` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filePath` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('SYLLABUS','SPECIFICATION','PAST_PAPER','MARK_SCHEME','GUIDE','LINK','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OTHER',
  `language` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qualificationId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paperId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceDocumentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Resource_examBoardId_idx` (`examBoardId`),
  KEY `Resource_qualificationId_idx` (`qualificationId`),
  KEY `Resource_subjectId_idx` (`subjectId`),
  KEY `Resource_paperId_idx` (`paperId`),
  KEY `Resource_examSeriesId_idx` (`examSeriesId`),
  KEY `Resource_sourceDocumentId_idx` (`sourceDocumentId`),
  KEY `Resource_type_idx` (`type`),
  CONSTRAINT `Resource_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Resource_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Resource_paperId_fkey` FOREIGN KEY (`paperId`) REFERENCES `Paper` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Resource_qualificationId_fkey` FOREIGN KEY (`qualificationId`) REFERENCES `Qualification` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Resource_sourceDocumentId_fkey` FOREIGN KEY (`sourceDocumentId`) REFERENCES `SourceDocument` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Resource_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Resource`
--

LOCK TABLES `Resource` WRITE;
/*!40000 ALTER TABLE `Resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `Resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReviewRequest`
--

DROP TABLE IF EXISTS `ReviewRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ReviewRequest` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationItemId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examSessionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paperId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serviceType` enum('REVIEW','PRIORITY_REVIEW','CLERICAL_CHECK','ACCESS_TO_SCRIPT','CASH_IN','CERTIFICATE','ADMINISTRATIVE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('DRAFT','SUBMITTED','APPROVED','SENT_TO_BOARD','COMPLETED','REJECTED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `requestedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resultOutcome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `feeStatementId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ReviewRequest_reviewWindowId_idx` (`reviewWindowId`),
  KEY `ReviewRequest_candidateId_idx` (`candidateId`),
  KEY `ReviewRequest_examBoardId_idx` (`examBoardId`),
  KEY `ReviewRequest_examSeriesId_idx` (`examSeriesId`),
  KEY `ReviewRequest_serviceType_idx` (`serviceType`),
  KEY `ReviewRequest_status_idx` (`status`),
  KEY `ReviewRequest_registrationItemId_idx` (`registrationItemId`),
  KEY `ReviewRequest_examSessionId_fkey` (`examSessionId`),
  KEY `ReviewRequest_subjectId_fkey` (`subjectId`),
  KEY `ReviewRequest_paperId_fkey` (`paperId`),
  KEY `ReviewRequest_requestedByUserId_fkey` (`requestedByUserId`),
  KEY `ReviewRequest_reviewedByUserId_fkey` (`reviewedByUserId`),
  KEY `ReviewRequest_feeStatementId_fkey` (`feeStatementId`),
  CONSTRAINT `ReviewRequest_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_examSessionId_fkey` FOREIGN KEY (`examSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_feeStatementId_fkey` FOREIGN KEY (`feeStatementId`) REFERENCES `FeeStatement` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_paperId_fkey` FOREIGN KEY (`paperId`) REFERENCES `Paper` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_registrationItemId_fkey` FOREIGN KEY (`registrationItemId`) REFERENCES `StudentExamRegistration` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_requestedByUserId_fkey` FOREIGN KEY (`requestedByUserId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_reviewedByUserId_fkey` FOREIGN KEY (`reviewedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_reviewWindowId_fkey` FOREIGN KEY (`reviewWindowId`) REFERENCES `ReviewWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ReviewRequest_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReviewRequest`
--

LOCK TABLES `ReviewRequest` WRITE;
/*!40000 ALTER TABLE `ReviewRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReviewRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReviewWindow`
--

DROP TABLE IF EXISTS `ReviewWindow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ReviewWindow` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resultsReleaseDate` datetime(3) DEFAULT NULL,
  `openAt` datetime(3) NOT NULL,
  `closeAt` datetime(3) NOT NULL,
  `status` enum('DRAFT','OPEN','CLOSED','LOCKED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdByUserId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ReviewWindow_examBoardId_idx` (`examBoardId`),
  KEY `ReviewWindow_examSeriesId_idx` (`examSeriesId`),
  KEY `ReviewWindow_status_idx` (`status`),
  KEY `ReviewWindow_openAt_closeAt_idx` (`openAt`,`closeAt`),
  KEY `ReviewWindow_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `ReviewWindow_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ReviewWindow_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ReviewWindow_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReviewWindow`
--

LOCK TABLES `ReviewWindow` WRITE;
/*!40000 ALTER TABLE `ReviewWindow` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReviewWindow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReviewWindowService`
--

DROP TABLE IF EXISTS `ReviewWindowService`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ReviewWindowService` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serviceType` enum('REVIEW','PRIORITY_REVIEW','CLERICAL_CHECK','ACCESS_TO_SCRIPT','CASH_IN','CERTIFICATE','ADMINISTRATIVE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ReviewWindowService_reviewWindowId_serviceType_key` (`reviewWindowId`,`serviceType`),
  KEY `ReviewWindowService_reviewWindowId_idx` (`reviewWindowId`),
  CONSTRAINT `ReviewWindowService_reviewWindowId_fkey` FOREIGN KEY (`reviewWindowId`) REFERENCES `ReviewWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReviewWindowService`
--

LOCK TABLES `ReviewWindowService` WRITE;
/*!40000 ALTER TABLE `ReviewWindowService` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReviewWindowService` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SourceDocument`
--

DROP TABLE IF EXISTS `SourceDocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SourceDocument` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('EXAM_TIMETABLE','KEY_DATES','REGISTRATION','RESULTS','SYLLABUS','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OTHER',
  `sourceUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileHash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publishedAt` datetime(3) DEFAULT NULL,
  `fetchedAt` datetime(3) DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploadedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `SourceDocument_examBoardId_idx` (`examBoardId`),
  KEY `SourceDocument_uploadedById_idx` (`uploadedById`),
  KEY `SourceDocument_type_idx` (`type`),
  KEY `SourceDocument_publishedAt_idx` (`publishedAt`),
  CONSTRAINT `SourceDocument_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `SourceDocument_uploadedById_fkey` FOREIGN KEY (`uploadedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SourceDocument`
--

LOCK TABLES `SourceDocument` WRITE;
/*!40000 ALTER TABLE `SourceDocument` DISABLE KEYS */;
/*!40000 ALTER TABLE `SourceDocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StudentExamRegistration`
--

DROP TABLE IF EXISTS `StudentExamRegistration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `StudentExamRegistration` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `studentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationWorkspaceId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examSessionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrationWindowId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examBoardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `examSeriesId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paperId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentNameSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentNoSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gradeSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classNameSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emailSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phoneSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assessmentHubCandidateNumberSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `candidateTypeSnapshot` enum('INTERNAL','EXTERNAL') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','CANCELLED','LOCKED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `lockedAt` datetime(3) DEFAULT NULL,
  `cancelledAt` datetime(3) DEFAULT NULL,
  `registrationSource` enum('STUDENT_SUBMITTED','TEACHER_REQUEST_APPROVED','EO_ASSISTED','ADMIN_ASSISTED','EO_FORCED_INTERNAL','ADMIN_FORCED_INTERNAL','EO_POST_LOCK_ADJUSTMENT','ADMIN_POST_LOCK_ADJUSTMENT','EXTERNAL_CANDIDATE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'STUDENT_SUBMITTED',
  `visibility` enum('STUDENT_AND_TEACHER','STUDENT_ONLY','EXAM_OFFICE_ONLY') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'STUDENT_AND_TEACHER',
  `billingScope` enum('NORMAL_BILLING','RESTRICTED_BILLING','EXTERNAL_BILLING','NO_BILLING','MANUAL_REVIEW') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL_BILLING',
  `addedByUserId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addedByRole` enum('ADMIN','EXAM_OFFICER','SUBJECT_TEACHER','STUDENT') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addedAt` datetime(3) DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `entryType` enum('NORMAL','LATE','HIGH_LATE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  `entryTypeOverridden` tinyint(1) NOT NULL DEFAULT '0',
  `entryTypeOverrideReason` text COLLATE utf8mb4_unicode_ci,
  `feeStageId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationType` enum('INTERNAL_NORMAL','RESTRICTED_INTERNAL','EXTERNAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INTERNAL_NORMAL',
  `visibleToStudent` tinyint(1) NOT NULL DEFAULT '1',
  `visibleToTeacher` tinyint(1) NOT NULL DEFAULT '1',
  `visibleInStudentPortal` tinyint(1) NOT NULL DEFAULT '1',
  `visibleInTeacherPortal` tinyint(1) NOT NULL DEFAULT '1',
  `visibleInStudentDocuments` tinyint(1) NOT NULL DEFAULT '1',
  `visibleInStudentBilling` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `StudentExamRegistration_candidateId_examSessionId_key` (`candidateId`,`examSessionId`),
  UNIQUE KEY `StudentExamRegistration_studentId_examSessionId_key` (`studentId`,`examSessionId`),
  KEY `StudentExamRegistration_candidateId_idx` (`candidateId`),
  KEY `StudentExamRegistration_studentId_idx` (`studentId`),
  KEY `StudentExamRegistration_registrationWorkspaceId_idx` (`registrationWorkspaceId`),
  KEY `StudentExamRegistration_examSessionId_idx` (`examSessionId`),
  KEY `StudentExamRegistration_registrationWindowId_idx` (`registrationWindowId`),
  KEY `StudentExamRegistration_examBoardId_idx` (`examBoardId`),
  KEY `StudentExamRegistration_examSeriesId_idx` (`examSeriesId`),
  KEY `StudentExamRegistration_subjectId_idx` (`subjectId`),
  KEY `StudentExamRegistration_status_idx` (`status`),
  KEY `StudentExamRegistration_registrationSource_idx` (`registrationSource`),
  KEY `StudentExamRegistration_visibility_idx` (`visibility`),
  KEY `StudentExamRegistration_billingScope_idx` (`billingScope`),
  KEY `StudentExamRegistration_gradeSnapshot_classNameSnapshot_idx` (`gradeSnapshot`,`classNameSnapshot`),
  KEY `StudentExamRegistration_studentNoSnapshot_idx` (`studentNoSnapshot`),
  KEY `StudentExamRegistration_paperId_fkey` (`paperId`),
  KEY `StudentExamRegistration_addedByUserId_fkey` (`addedByUserId`),
  KEY `StudentExamRegistration_entryType_idx` (`entryType`),
  KEY `StudentExamRegistration_feeStageId_idx` (`feeStageId`),
  KEY `StudentExamRegistration_registrationType_idx` (`registrationType`),
  CONSTRAINT `StudentExamRegistration_addedByUserId_fkey` FOREIGN KEY (`addedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_candidateId_fkey` FOREIGN KEY (`candidateId`) REFERENCES `Candidate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_examBoardId_fkey` FOREIGN KEY (`examBoardId`) REFERENCES `ExamBoard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_examSeriesId_fkey` FOREIGN KEY (`examSeriesId`) REFERENCES `ExamSeries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_examSessionId_fkey` FOREIGN KEY (`examSessionId`) REFERENCES `ExamSession` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_feeStageId_fkey` FOREIGN KEY (`feeStageId`) REFERENCES `RegistrationFeeStage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_paperId_fkey` FOREIGN KEY (`paperId`) REFERENCES `Paper` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_registrationWindowId_fkey` FOREIGN KEY (`registrationWindowId`) REFERENCES `RegistrationWindow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_registrationWorkspaceId_fkey` FOREIGN KEY (`registrationWorkspaceId`) REFERENCES `RegistrationWorkspace` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_studentId_fkey` FOREIGN KEY (`studentId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `StudentExamRegistration_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StudentExamRegistration`
--

LOCK TABLES `StudentExamRegistration` WRITE;
/*!40000 ALTER TABLE `StudentExamRegistration` DISABLE KEYS */;
/*!40000 ALTER TABLE `StudentExamRegistration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StudentProfile`
--

DROP TABLE IF EXISTS `StudentProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `StudentProfile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currentGrade` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currentClassName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','GRADUATED','LEFT','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `entryYear` int DEFAULT NULL,
  `graduationYear` int DEFAULT NULL,
  `graduatedAt` datetime(3) DEFAULT NULL,
  `leftAt` datetime(3) DEFAULT NULL,
  `archivedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `idCardNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('MALE','FEMALE','OTHER','PREFER_NOT_TO_SAY') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `StudentProfile_userId_key` (`userId`),
  UNIQUE KEY `StudentProfile_studentNo_key` (`studentNo`),
  KEY `StudentProfile_currentGrade_idx` (`currentGrade`),
  KEY `StudentProfile_currentClassName_idx` (`currentClassName`),
  KEY `StudentProfile_status_idx` (`status`),
  KEY `StudentProfile_studentNo_idx` (`studentNo`),
  CONSTRAINT `StudentProfile_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StudentProfile`
--

LOCK TABLES `StudentProfile` WRITE;
/*!40000 ALTER TABLE `StudentProfile` DISABLE KEYS */;
INSERT INTO `StudentProfile` VALUES ('cmr0viwt30008lz8bsbw6isff','cmr0viwss0006lz8b9nzdsicd','S2026001','Year 12','12A','student@xima.local','+8613800000002','ACTIVE',2024,NULL,NULL,NULL,NULL,'2026-06-30 16:41:23.607','2026-06-30 16:41:23.607',NULL,NULL),('cmr0vix7u000blz8b1rwkm3b8','cmr0vix7i0009lz8be7nmdm2v','S2026002','Year 11','11B','student2@xima.local','+8613800000003','ACTIVE',2025,NULL,NULL,NULL,NULL,'2026-06-30 16:41:24.138','2026-06-30 16:41:24.138',NULL,NULL);
/*!40000 ALTER TABLE `StudentProfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Subject`
--

DROP TABLE IF EXISTS `Subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Subject` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualificationId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Subject_qualificationId_idx` (`qualificationId`),
  CONSTRAINT `Subject_qualificationId_fkey` FOREIGN KEY (`qualificationId`) REFERENCES `Qualification` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Subject`
--

LOCK TABLES `Subject` WRITE;
/*!40000 ALTER TABLE `Subject` DISABLE KEYS */;
INSERT INTO `Subject` VALUES ('seed-subject-aqa-maths','Mathematics','8300','seed-qual-aqa-gcse-maths','2026-06-30 16:41:21.813','2026-06-30 16:41:21.813'),('seed-subject-aqa-physics','Physics','7408','seed-qual-aqa-alevel-physics','2026-06-30 16:41:21.817','2026-06-30 16:41:21.817'),('seed-subject-cie-maths','Mathematics','0580','seed-qual-cie-igcse-maths','2026-06-30 16:41:21.819','2026-06-30 16:41:21.819'),('seed-subject-edexcel-maths','Mathematics','1MA1','seed-qual-edexcel-gcse-maths','2026-06-30 16:41:21.821','2026-06-30 16:41:21.821');
/*!40000 ALTER TABLE `Subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SystemEmailSettings`
--

DROP TABLE IF EXISTS `SystemEmailSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SystemEmailSettings` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `smtpHost` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtpPort` int NOT NULL DEFAULT '587',
  `smtpSecure` tinyint(1) NOT NULL DEFAULT '0',
  `smtpUser` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtpPassword` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mailFrom` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passwordResetExpiresMinutes` int NOT NULL DEFAULT '60',
  `appUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SystemEmailSettings`
--

LOCK TABLES `SystemEmailSettings` WRITE;
/*!40000 ALTER TABLE `SystemEmailSettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `SystemEmailSettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TeacherAssignment`
--

DROP TABLE IF EXISTS `TeacherAssignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TeacherAssignment` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacherId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subjectId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TeacherAssignment_teacherId_subjectId_key` (`teacherId`,`subjectId`),
  KEY `TeacherAssignment_teacherId_idx` (`teacherId`),
  KEY `TeacherAssignment_subjectId_idx` (`subjectId`),
  CONSTRAINT `TeacherAssignment_subjectId_fkey` FOREIGN KEY (`subjectId`) REFERENCES `Subject` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `TeacherAssignment_teacherId_fkey` FOREIGN KEY (`teacherId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TeacherAssignment`
--

LOCK TABLES `TeacherAssignment` WRITE;
/*!40000 ALTER TABLE `TeacherAssignment` DISABLE KEYS */;
INSERT INTO `TeacherAssignment` VALUES ('cmr0vix7z000dlz8bpjna2kz6','cmr0viw8y0005lz8b0fsvz2wn','seed-subject-aqa-physics','2026-06-30 16:41:24.143','2026-06-30 16:41:24.143');
/*!40000 ALTER TABLE `TeacherAssignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TeacherProfile`
--

DROP TABLE IF EXISTS `TeacherProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TeacherProfile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `visibleGrades` json DEFAULT NULL,
  `visibleClasses` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TeacherProfile_userId_key` (`userId`),
  KEY `TeacherProfile_status_idx` (`status`),
  CONSTRAINT `TeacherProfile_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TeacherProfile`
--

LOCK TABLES `TeacherProfile` WRITE;
/*!40000 ALTER TABLE `TeacherProfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `TeacherProfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `studentNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passwordHash` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('ADMIN','EXAM_OFFICER','SUBJECT_TEACHER','STUDENT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'STUDENT',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `mustChangePassword` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_username_key` (`username`),
  UNIQUE KEY `User_email_key` (`email`),
  UNIQUE KEY `User_phone_key` (`phone`),
  UNIQUE KEY `User_studentNo_key` (`studentNo`),
  KEY `User_role_idx` (`role`),
  KEY `User_isActive_idx` (`isActive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('cmr0vivda0000lz8bmmywok09','Admin','admin','admin@xima.local',NULL,NULL,'$2b$12$fPG3btNBuqGqGoOxMFt39uVM78qxbNL82YFIbj9LVid0AZ3JLDNMy','ADMIN',1,0,'2026-06-30 16:41:21.742','2026-06-30 16:41:21.742'),('cmr0vivu90004lz8biu6vns4d','Exam Officer','examofficer','exam.officer@xima.local',NULL,NULL,'$2b$12$v09ckU7oWZXdsPGAhu6g0eYdFxwK40R2ThzH7RvilRxTWEbr3MoAC','EXAM_OFFICER',1,0,'2026-06-30 16:41:22.353','2026-06-30 16:41:22.353'),('cmr0viw8y0005lz8b0fsvz2wn','Physics Teacher',NULL,'teacher@xima.local','+8613800000001',NULL,'$2b$12$y32kFEZM2FbP1p/YZZgtSuXNjaZdtnz02fsiGszrxdwEakk3r30qq','SUBJECT_TEACHER',1,0,'2026-06-30 16:41:22.883','2026-06-30 16:41:22.883'),('cmr0viwss0006lz8b9nzdsicd','Sample Student',NULL,'student@xima.local','+8613800000002','S2026001','$2b$12$t.pIZu3WJQ3XNLMCUEV1uObfeEHrfYT/Y9mkPLqauj0Xmt02tmKYC','STUDENT',1,0,'2026-06-30 16:41:23.596','2026-06-30 16:41:23.596'),('cmr0vix7i0009lz8be7nmdm2v','Test Student Two',NULL,'student2@xima.local','+8613800000003','S2026002','$2b$12$.LUiemwuHNoel0iGzzMDuOKoKOM7fv7MkDGGxt1eJlsSD/AfFPrnW','STUDENT',1,0,'2026-06-30 16:41:24.126','2026-06-30 16:41:24.126');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserAuditLog`
--

DROP TABLE IF EXISTS `UserAuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserAuditLog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` enum('USER_CREATED','USER_UPDATED','USER_DEACTIVATED','PASSWORD_RESET_REQUESTED','PASSWORD_RESET_COMPLETED','STUDENT_IMPORTED','TEACHER_IMPORTED','STUDENT_PROMOTED','STUDENT_ARCHIVED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetUserId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performedById` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `UserAuditLog_action_idx` (`action`),
  KEY `UserAuditLog_targetUserId_idx` (`targetUserId`),
  KEY `UserAuditLog_performedById_idx` (`performedById`),
  KEY `UserAuditLog_createdAt_idx` (`createdAt`),
  CONSTRAINT `UserAuditLog_performedById_fkey` FOREIGN KEY (`performedById`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `UserAuditLog_targetUserId_fkey` FOREIGN KEY (`targetUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserAuditLog`
--

LOCK TABLES `UserAuditLog` WRITE;
/*!40000 ALTER TABLE `UserAuditLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserAuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('06af59fd-b5e6-4f51-aae4-772bf28e0fc3','8f58f11a0e32972b03e455751a2df0b50202dd722eba34166eb95039f7d46be7','2026-06-30 16:41:05.469','20260626180000_registration_window_timing_refactor',NULL,NULL,'2026-06-30 16:41:05.461',1),('0f4af5e0-f1b5-4876-8b90-5d909b82522e','069c373cb7a67e319cd83e4f061969a179b29026961218c612fdf82430590d44','2026-06-30 16:41:19.842','20260713120000_audit_log_billing_scope',NULL,NULL,'2026-06-30 16:41:19.770',1),('1911d420-69dc-4085-b6f5-bbccb8bfb164','02420ccd069414b36d248251428468f3fee698e42330c619dd21cac8674b9d71','2026-06-30 16:41:15.017','20260628155500_registration_window_timing_apply',NULL,NULL,'2026-06-30 16:41:14.286',1),('1f3c5563-9cc6-4bc7-9015-97dc46fccd38','18c12cb69438fcc203e7b9511d83f7b2a6454f60f341e460614446263cf8d5e7','2026-06-30 16:41:15.270','20260629160000_student_gender_email_settings',NULL,NULL,'2026-06-30 16:41:15.223',1),('28f6338a-4222-4c7d-bfc8-7f17178d66d8','82376f5c4cc44e6ba35d9005b443f1df17eae630c2fa582b4f8425d7f43c9c06','2026-06-30 16:41:18.933','20260708120000_fee_statement_lifecycle',NULL,NULL,'2026-06-30 16:41:18.615',1),('33101de7-acee-4286-9396-b94339f1b564','5f0d1f677870612d76329eda5e8cb50519b8a4f70794b31860f9de57ee3766cb','2026-06-30 16:41:19.706','20260711120000_registration_confirmation_number',NULL,NULL,'2026-06-30 16:41:19.609',1),('4893e82f-3caa-437e-a11d-26c15b7e78a1','8eb12f876d6799a087ce9b47568848d13d6f59a6b8b000d791f1b55f9ed964ac','2026-06-30 16:41:12.780','20260628151332_add_text_fields',NULL,NULL,'2026-06-30 16:41:12.468',1),('4f3e8864-f497-40ef-b066-2e7a01aa72b8','0405f7821c73db0126ff4a5f9d45d2f24156a3c0e381c02bab757627235ea956','2026-06-30 16:41:15.667','20260701120000_exam_board_centre_settings',NULL,NULL,'2026-06-30 16:41:15.634',1),('61a81772-9807-4387-aa8a-236c696e3b93','e2bba6fddd8c74e717fe4a55e3cb79675f7b6c38214a5f67d19bdfc7e31216ec','2026-06-30 16:41:19.546','20260709120000_registration_workflow_refine',NULL,NULL,'2026-06-30 16:41:18.937',1),('6531feff-a0d2-4f8f-ae09-e51c2bb64f5c','98ce333f96824f586ebb1f6f2eaee9eb35ab61f14bd97eeb99a30c7c769e62c8','2026-06-30 16:41:15.709','20260702120000_workspace_unique_by_registration_type',NULL,NULL,'2026-06-30 16:41:15.669',1),('7904f7ae-f804-4853-a732-4bc393e0f9da','2e9a69fa8b31286b6f2edff56bb6f5f5a4dade55328a90b9c89c3d44743214ac','2026-06-30 16:41:15.724','20260703120000_fee_statement_kind_external',NULL,NULL,'2026-06-30 16:41:15.712',1),('8297e607-431d-4d2b-9219-19e730a9758b','9716b9812f09539482ea8b2cc40ed00ff4660ab3d224bd1a102be31c30b0b88c','2026-06-30 16:41:15.633','20260630120000_exam_documents_restricted_registration',NULL,NULL,'2026-06-30 16:41:15.271',1),('8c17e48c-e202-43cb-87d8-5c5269da536f','4b8f2e9f12765cca0f5a22334a83adb39decd1a62689e63e1d8095350c604152','2026-06-30 16:41:14.283','20260628155053_add_registration_stages',NULL,NULL,'2026-06-30 16:41:12.782',1),('8ce9ed0b-44af-4f97-ba13-8651d2a507a9','66caf673f6081fc72ffc175fe1e93ff44be8e6b95e02b6b3bb33246319c214a0','2026-06-30 16:41:15.222','20260629140000_user_identity_management',NULL,NULL,'2026-06-30 16:41:15.106',1),('906e9b64-60e4-49bd-8197-693fe9961ff3','7badfc1af8c0dfe572895fb1f8e23ba0c786d1dc60dc8e395be5f2869d1a04b4','2026-06-30 16:41:15.971','20260705120000_registration_window_academic_year',NULL,NULL,'2026-06-30 16:41:15.869',1),('a8674248-41e3-46fd-b539-0b48b1839826','2c3a8259d7a36485c6bd1e011810f83079c642d0123f4a2bcf3ac0281fc03df9','2026-06-30 16:41:15.867','20260704120000_candidate_identity_profile',NULL,NULL,'2026-06-30 16:41:15.726',1),('adeb0795-3c99-44b2-b1f2-c9303f9bee6d','94503e6dfad63029abb6f0b767abbc0261e4e2433030476ff6428641c4ec411d','2026-06-30 16:41:12.466','20260628145606_init',NULL,NULL,'2026-06-30 16:41:05.474',1),('af9ec761-7f31-4948-b6a8-64e32f9ca27e','fde50d9d39e209f1dfb3d9c744679a6869a583d3ac6c15941840e6bc20db02d3','2026-06-30 16:41:18.613','20260707120000_candidate_registration_fee_manual',NULL,NULL,'2026-06-30 16:41:18.527',1),('b6cb0310-31bd-45de-955e-a624e3c8593d','45005341e1e2110471b47c99995e593f7fc0fb57996c456cedc53f5de438b127','2026-06-30 16:41:19.767','20260712120000_registration_audit_payload',NULL,NULL,'2026-06-30 16:41:19.707',1),('e142eaf7-28e8-4ea9-b63b-181960d5cb3b','7bfb0b9e00eb01e9c4aa5914e54a867ff26f0689881fd9f8421d30aa72cbcce2','2026-06-30 16:41:18.526','20260706120000_post_results_domain',NULL,NULL,'2026-06-30 16:41:15.975',1),('e3752618-3da7-4260-b13a-9f08b3ddffe8','66bf424914a644ea3e19fb91cc59ae9595eea0513e459be2c0a88fd65e45e690','2026-06-30 16:41:15.105','20260629120000_registration_window_included_series',NULL,NULL,'2026-06-30 16:41:15.018',1),('fb58a8c4-f5bb-4448-adb3-45aae2cb7eff','86feaf1031b5cfdac4916f1955e722da7bb1ae2dea9ad6338356085aabfb5bb1','2026-06-30 16:41:19.607','20260710120000_registration_workspace_reason',NULL,NULL,'2026-06-30 16:41:19.547',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'xima_assessment_hub'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-30 16:42:25
